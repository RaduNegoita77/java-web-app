package project;

import org.junit.jupiter.api.Test;
import project.model.User;
import project.exception.InvalidInputException;
import static org.junit.jupiter.api.Assertions.*;

public class UserTest {
    @Test
    public void testConstructors() throws InvalidInputException {
        User u = new User("1", "admin_test", "Nume", "ADMIN");
        assertEquals("ADMIN", u.getRole());
    }

    @Test
    public void testInvalidUser() {
        assertThrows(InvalidInputException.class, () -> new User("1", "a", "Nume", "USER"));
    }
}